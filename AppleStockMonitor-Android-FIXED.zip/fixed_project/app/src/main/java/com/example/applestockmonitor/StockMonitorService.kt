package com.example.applestockmonitor

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class StockMonitorService : Service() {

    companion object {
        const val CHANNEL_ID = "apple_stock_monitor"
        const val NOTIFICATION_ID = 2001
        const val PART = "MDH74CH/A"
        const val PRODUCT_URL =
            "https://www.apple.com.cn/shop/buy-mac/macbook-air/13-inch-silver-m5-chip-10-core-cpu-8-core-gpu-16gb-memory-512gb-storage"

        private val STORES = linkedMapOf(
            "R388" to "西单大悦城",
            "R448" to "王府井",
            "R320" to "三里屯",
            "R645" to "朝阳大悦城"
        )
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    @Volatile private var running = true
    private var worker: Thread? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, baseNotification("正在监控 Apple Store 库存…"))
        worker = thread(start = true, name = "AppleStockMonitor") { loop() }
    }

    private fun loop() {
        var previous = mutableMapOf<String, Boolean>()
        while (running) {
            try {
                val current = checkAllStores()
                current.forEach { (id, available) ->
                    val was = previous[id]
                    if (available && was != true) {
                        notifyStock(STORES[id] ?: id)
                    }
                }
                previous = current.toMutableMap()
            } catch (_: Exception) {
                // 网络/API异常不当成“无货”，避免误报。
            }
            for (i in 1..60) {
                if (!running) break
                Thread.sleep(1000)
            }
        }
    }

    private fun checkAllStores(): Map<String, Boolean> {
        val result = mutableMapOf<String, Boolean>()
        for ((storeId, _) in STORES) {
            val url = "https://www.apple.com.cn/shop/retail/pickup-message" +
                    "?pl=true&mts.0=regular&parts.0=${java.net.URLEncoder.encode(PART, "UTF-8")}" +
                    "&store=$storeId"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android) AppleStockMonitor/1.0")
                .header("Accept", "application/json,text/plain,*/*")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use
                val text = response.body?.string() ?: return@use
                val root = JSONObject(text)
                val stores = root.optJSONObject("body")?.optJSONArray("stores") ?: return@use

                for (i in 0 until stores.length()) {
                    val s = stores.optJSONObject(i) ?: continue
                    if (s.optString("storeNumber") != storeId) continue
                    val availability = s.optJSONObject("partsAvailability")
                    val part = availability?.optJSONObject(PART)
                    val state = part?.optString("pickupDisplay")
                    result[storeId] = (state == "available")
                    break
                }
            }
            Thread.sleep(300)
        }
        return result
    }

    private fun notifyStock(storeName: String) {
        val pending = PendingIntent.getActivity(
            this, 500,
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(PRODUCT_URL)),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🚨 MacBook Air M5 有货！")
            .setContentText("$storeName Apple Store 有货，点击立即查看")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("MacBook Air 13" M5 · 银色 · 16GB/512GB\n$storeName 有货！"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify((10000..20000).random(), notification)
    }

    private fun baseNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Apple库存监控")
            .setContentText(text)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Apple库存监控",
                NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
