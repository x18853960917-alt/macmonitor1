package com.example.applestockmonitor

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }

        val title = TextView(this).apply {
            text = "🍎 Apple MacBook 库存监控"
            textSize = 22f
            setPadding(24, 28, 24, 18)
        }

        val info = TextView(this).apply {
            text = """
                商品：MacBook Air 13" M5
                银色 · 16GB · 512GB
                型号：MDH74CH/A

                监控门店：
                • 西单大悦城
                • 王府井
                • 三里屯
                • 朝阳大悦城

                检查间隔：约 60 秒
            """.trimIndent()
            textSize = 16f
            setPadding(24, 8, 24, 20)
        }

        val status = TextView(this).apply {
            text = "状态：尚未启动"
            textSize = 16f
            setPadding(24, 8, 24, 20)
        }

        val start = Button(this).apply {
            text = "开始后台监控"
            setOnClickListener {
                val intent = Intent(this@MainActivity, StockMonitorService::class.java)
                ContextCompat.startForegroundService(this@MainActivity, intent)
                status.text = "状态：监控运行中（请保持通知权限开启）"
            }
        }

        val stop = Button(this).apply {
            text = "停止监控"
            setOnClickListener {
                stopService(Intent(this@MainActivity, StockMonitorService::class.java))
                status.text = "状态：已停止"
            }
        }

        val open = Button(this).apply {
            text = "打开 Apple 商品页"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse(StockMonitorService.PRODUCT_URL)))
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(info)
            addView(status)
            addView(start)
            addView(stop)
            addView(open)
        }
        setContentView(layout)
    }
}
