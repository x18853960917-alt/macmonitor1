# Apple MacBook 库存监控 Android App

固定监控中国大陆 Apple Store：

- MacBook Air 13" M5
- 10 核 CPU / 8 核 GPU
- 银色
- 16GB / 512GB
- Part Number: MDH74CH/A
- 北京：西单大悦城、王府井、三里屯、朝阳大悦城
- 默认约 60 秒检查一次
- 无货→有货时发送 Android 通知

## 注意
Android 为了允许约 60 秒后台轮询，程序使用前台服务，因此手机通知栏会一直显示“Apple库存监控”。

部分国产 Android 系统还需要手动允许：
1. 自启动
2. 后台运行
3. 不受电池优化限制
4. 通知权限

Apple 库存可能在你点击购买时已经被其他人拿走，因此“收到通知”不等于一定能成功预约。

库存接口使用 Apple 中国大陆目前可用的 `/shop/retail/pickup-message`。
